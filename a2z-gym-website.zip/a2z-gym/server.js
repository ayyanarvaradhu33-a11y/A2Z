// A2Z Fitness Studio — backend
// Serves the frontend and powers two small live features:
//   GET  /api/status    -> is the gym open right now, and when does that change
//   POST /api/inquiry   -> save a trial/membership inquiry from the contact form
//   GET  /api/inquiries -> list saved inquiries (basic admin view, see README)

const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "inquiries.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Real weekly hours for A2Z Fitness Studio.
// Each day: array of [openHour, closeHour] in 24h decimal (5.5 = 5:30 AM). Empty = closed.
const HOURS = {
  0: [], // Sunday — closed
  1: [[5.5, 10], [16, 21]],
  2: [[5.5, 10], [16, 21]],
  3: [[5.5, 10], [16, 21]],
  4: [[5.5, 10], [16, 21]],
  5: [[5.5, 10], [16, 21]],
  6: [[5.5, 10], [16, 21]],
};

function formatHour(h) {
  const hour24 = Math.floor(h);
  const minute = Math.round((h - hour24) * 60);
  const period = hour24 >= 12 ? "PM" : "AM";
  let hour12 = hour24 % 12;
  if (hour12 === 0) hour12 = 12;
  return `${hour12}:${minute.toString().padStart(2, "0")} ${period}`;
}

function getStatus(now = new Date()) {
  const day = now.getDay();
  const decimalHour = now.getHours() + now.getMinutes() / 60;
  const todayBlocks = HOURS[day];

  for (const [open, close] of todayBlocks) {
    if (decimalHour >= open && decimalHour < close) {
      return {
        open: true,
        day,
        message: `Open now — closes ${formatHour(close)}`,
        changesAt: formatHour(close),
      };
    }
  }

  // Find the next block today or on a following day
  let nextOpen = todayBlocks.find(([open]) => decimalHour < open);
  let daysAhead = 0;
  let searchDay = day;
  while (!nextOpen && daysAhead < 7) {
    daysAhead += 1;
    searchDay = (day + daysAhead) % 7;
    nextOpen = HOURS[searchDay][0];
  }

  if (!nextOpen) {
    return { open: false, day, message: "Closed", changesAt: null };
  }

  const dayLabel = daysAhead === 0 ? "today" : daysAhead === 1 ? "tomorrow" : ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][searchDay];
  return {
    open: false,
    day,
    message: `Closed — opens ${formatHour(nextOpen[0])} ${dayLabel}`,
    changesAt: formatHour(nextOpen[0]),
  };
}

app.get("/api/status", (req, res) => {
  res.json(getStatus());
});

app.get("/api/hours", (req, res) => {
  res.json(HOURS);
});

function readInquiries() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return [];
  }
}

function writeInquiries(list) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2));
}

app.post("/api/inquiry", (req, res) => {
  const { name, phone, goal, preferredTime } = req.body || {};

  if (!name || !phone) {
    return res.status(400).json({ error: "Name and phone are required." });
  }
  if (!/^[0-9+\s-]{7,15}$/.test(phone)) {
    return res.status(400).json({ error: "That phone number doesn't look right." });
  }

  const inquiry = {
    id: Date.now(),
    name: String(name).slice(0, 100),
    phone: String(phone).slice(0, 20),
    goal: String(goal || "Not specified").slice(0, 200),
    preferredTime: String(preferredTime || "Not specified").slice(0, 50),
    receivedAt: new Date().toISOString(),
  };

  const list = readInquiries();
  list.push(inquiry);
  writeInquiries(list);

  res.status(201).json({ status: "ok", message: "Thanks — we'll call you back shortly." });
});

// Basic admin list — no auth. Fine for local/dev use.
// Before deploying publicly, put this behind a login (see README).
app.get("/api/inquiries", (req, res) => {
  res.json(readInquiries());
});

app.listen(PORT, () => {
  console.log(`A2Z Fitness Studio site running at http://localhost:${PORT}`);
});
