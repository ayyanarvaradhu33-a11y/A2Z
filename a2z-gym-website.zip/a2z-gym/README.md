# A2Z Fitness Studio — website

A frontend + backend site for A2Z Fitness Studio (Acharapakkam, Tamil Nadu).

## What's here

```
a2z-gym/
├── server.js          Express backend
├── package.json
├── data/               inquiries.json is created here at runtime
└── public/             frontend (served by the backend)
    ├── index.html
    ├── styles.css
    └── script.js
```

## Run it

Requires [Node.js](https://nodejs.org) 18+.

```bash
cd a2z-gym
npm install
npm start
```

Then open **http://localhost:3000**.

## What the backend actually does

- **`GET /api/status`** — computes live open/closed status from the real
  weekly hours and returns a message like "Open now — closes 9:00 PM". The
  header badge polls this every 60 seconds.
- **`POST /api/inquiry`** — the "Request a call back" form on the site posts
  here. Submissions are validated (name + phone required) and appended to
  `data/inquiries.json`.
- **`GET /api/inquiries`** — lists saved inquiries as JSON. This has **no
  authentication** — fine for local use, but add a login (or move it behind
  an admin-only route) before putting this on the public internet.

If the backend isn't running (e.g. you open `public/index.html` directly as
a file), the frontend still works — it falls back to computing the open/
closed status locally, and the form shows a "call us directly" message
instead of failing silently.

## Editing gym details

Everything specific to the gym — address, phone, hours, programs, the
review — lives in plain text in `public/index.html`, plus the same hours
object duplicated in `server.js` (`HOURS`) and `public/script.js`
(`HOURS`). Keep those three in sync if the schedule ever changes.

## The animation

The heartbeat/pulse line in the hero and the weekly schedule section isn't
decorative — it's drawn directly from the real open hours: flat when
closed, spiking through each open block. `buildPulsePath()` in
`public/script.js` generates it as an SVG path; the hero draws it once on
load with a stroke-dashoffset reveal.

## Deploying

Any Node host works (Render, Railway, a VPS, etc.). Set the `PORT`
environment variable if your host requires it — the server already reads
`process.env.PORT`.
