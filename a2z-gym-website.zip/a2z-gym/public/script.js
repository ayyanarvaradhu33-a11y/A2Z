// A2Z Fitness Studio — frontend behaviour

const HOURS = {
  0: [], // Sunday
  1: [[5.5, 10], [16, 21]],
  2: [[5.5, 10], [16, 21]],
  3: [[5.5, 10], [16, 21]],
  4: [[5.5, 10], [16, 21]],
  5: [[5.5, 10], [16, 21]],
  6: [[5.5, 10], [16, 21]],
};
const DAY_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

/**
 * Build an SVG path string that looks like a heartbeat monitor:
 * flat baseline, with a small "QRS" spike cluster during each open block.
 * @param {[number, number][]} blocks - open intervals in decimal hours (0-24)
 * @param {number} width - viewBox width
 * @param {number} baseline - y value of the flat line
 * @param {number} amplitude - height of the spikes
 */
function buildPulsePath(blocks, width = 1000, baseline = 70, amplitude = 34) {
  const hourToX = (h) => (h / 24) * width;
  let d = `M0,${baseline}`;
  let cursor = 0;

  const sortedBlocks = [...blocks].sort((a, b) => a[0] - b[0]);

  sortedBlocks.forEach(([openH, closeH]) => {
    const startX = hourToX(openH);
    const endX = hourToX(closeH);

    // flat run up to the block
    if (startX > cursor) d += ` L${startX.toFixed(1)},${baseline}`;

    // heartbeat blips across the block width
    const blockWidth = endX - startX;
    const blipWidth = 26;
    const blipCount = Math.max(2, Math.floor(blockWidth / blipWidth));
    const step = blockWidth / blipCount;
    let x = startX;

    for (let i = 0; i < blipCount; i++) {
      const small = amplitude * 0.35;
      d += ` L${(x + step * 0.18).toFixed(1)},${(baseline - small).toFixed(1)}`;
      d += ` L${(x + step * 0.32).toFixed(1)},${(baseline + amplitude).toFixed(1)}`;
      d += ` L${(x + step * 0.48).toFixed(1)},${(baseline - amplitude * 1.15).toFixed(1)}`;
      d += ` L${(x + step * 0.64).toFixed(1)},${(baseline + small * 0.6).toFixed(1)}`;
      d += ` L${(x + step * 0.82).toFixed(1)},${baseline.toFixed(1)}`;
      x += step;
    }

    d += ` L${endX.toFixed(1)},${baseline}`;
    cursor = endX;
  });

  if (cursor < width) d += ` L${width},${baseline}`;
  return d;
}

// ---- Hero pulse (today's schedule) ----
function paintHeroPulse() {
  const today = new Date().getDay();
  const path = document.getElementById("hero-pulse-path");
  if (path) path.setAttribute("d", buildPulsePath(HOURS[today]));
}

// ---- Weekly schedule rows ----
function paintScheduleRows() {
  const list = document.getElementById("schedule-list");
  if (!list) return;
  const today = new Date().getDay();

  const rowsHtml = [1, 2, 3, 4, 5, 6, 0].map((day) => {
    const blocks = HOURS[day];
    const closed = blocks.length === 0;
    const hoursLabel = closed
      ? "Closed"
      : blocks.map(([o, c]) => `${formatHour(o)}–${formatHour(c)}`).join(" · ");
    const path = closed ? "M0,17 L1000,17" : buildPulsePath(blocks, 1000, 17, 13);
    const todayClass = day === today ? " is-today" : "";

    return `
      <div class="schedule-row ${closed ? "is-closed" : ""}${todayClass}">
        <span class="schedule-day">${DAY_NAMES[day]}</span>
        <svg class="schedule-svg" viewBox="0 0 1000 34" preserveAspectRatio="none">
          <path class="row-line" d="${path}" />
        </svg>
        <span class="schedule-hours">${hoursLabel}</span>
      </div>`;
  }).join("");

  list.innerHTML = rowsHtml;
}

function formatHour(h) {
  const hour24 = Math.floor(h);
  const minute = Math.round((h - hour24) * 60);
  const period = hour24 >= 12 ? "PM" : "AM";
  let hour12 = hour24 % 12;
  if (hour12 === 0) hour12 = 12;
  return minute === 0 ? `${hour12} ${period}` : `${hour12}:${minute.toString().padStart(2, "0")} ${period}`;
}

// ---- Live open/closed status (asks the backend; falls back to local calc) ----
function computeLocalStatus() {
  const now = new Date();
  const day = now.getDay();
  const decimalHour = now.getHours() + now.getMinutes() / 60;
  const blocks = HOURS[day];
  const openBlock = blocks.find(([o, c]) => decimalHour >= o && decimalHour < c);
  if (openBlock) return { open: true, message: `Open now — closes ${formatHour(openBlock[1])}` };
  return { open: false, message: "Closed now" };
}

async function paintStatus() {
  const dot = document.getElementById("nav-status-dot");
  const text = document.getElementById("nav-status-text");
  if (!dot || !text) return;

  let status;
  try {
    const res = await fetch("/api/status");
    if (!res.ok) throw new Error("bad response");
    status = await res.json();
  } catch {
    status = computeLocalStatus(); // works even without the backend running
  }

  dot.classList.toggle("is-open", status.open);
  dot.classList.toggle("is-closed", !status.open);
  text.textContent = status.message;
}

// ---- Scroll reveal ----
function initReveal() {
  const items = document.querySelectorAll(".reveal");
  const cardGroups = document.querySelectorAll(".about-grid, .program-grid");
  cardGroups.forEach((group) => {
    [...group.children].forEach((child, i) => child.style.setProperty("--delay", `${i * 0.08}s`));
  });

  if (!("IntersectionObserver" in window)) {
    items.forEach((el) => el.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  items.forEach((el) => observer.observe(el));
}

// ---- Contact form ----
function initForm() {
  const form = document.getElementById("join");
  const statusEl = document.getElementById("form-status");
  const submitBtn = document.getElementById("submit-btn");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    statusEl.textContent = "";
    statusEl.className = "form-status";

    const payload = {
      name: document.getElementById("field-name").value.trim(),
      phone: document.getElementById("field-phone").value.trim(),
      goal: document.getElementById("field-goal").value,
      preferredTime: document.getElementById("field-time").value,
    };

    if (!payload.name || !payload.phone) {
      statusEl.textContent = "Please add your name and phone number.";
      statusEl.classList.add("err");
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Sending…";

    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Something went wrong.");

      statusEl.textContent = data.message || "Thanks — we'll call you back shortly.";
      statusEl.classList.add("ok");
      form.reset();
    } catch (err) {
      // Also covers the case where this page is opened directly as a file,
      // with no backend running to receive the request.
      statusEl.textContent = "Couldn't reach the server — call us directly at +91 63859 06099.";
      statusEl.classList.add("err");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Request a call back";
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  paintHeroPulse();
  paintScheduleRows();
  paintStatus();
  initReveal();
  initForm();
  setInterval(paintStatus, 60000); // keep the OPEN/CLOSED badge accurate
});
